Config = {}

Config.CarWashAmounth = 20
Config.framework = "esx" -- "esx" or   "qb"

Config.Locations = {
    {
        coords = vector3(26.58, -1391.88, 28.37),
    },
    {
        coords = vector3(169.35, -1716.72, 28.30),
    },
    {
        coords = vector3(-699.78, -933.04, 18.02),
    },
    {
        coords = vector3(1361.88, 3592.44, 33.95),
    },
    {
        coords = vector3(1694.55, 3589.8, 34.62),
    }
}