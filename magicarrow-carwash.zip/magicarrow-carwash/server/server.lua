if Config.framework == "esx" then
    ESX = nil

    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end) 
    
elseif Config.framework == "qb" then
    QBCore = nil
    TriggerEvent("QBCore:GetObject", function(library) 
        QBCore = library 
    end)
end

RegisterServerEvent("magicarrow-carwash-server:watereffect")
AddEventHandler("magicarrow-carwash-server:watereffect", function(coords)
	TriggerClientEvent("magicarrow-carwash:watereffect", -1, coords)
	TriggerClientEvent("magicarrow-carwash:watereffect2", -1, coords)
	TriggerClientEvent("magicarrow-carwash:watereffect3", -1, coords)
	TriggerClientEvent("magicarrow-carwash:watereffect4", -1, coords)
end)

RegisterServerEvent('magicarrow-carwash:moneycontrol')
AddEventHandler('magicarrow-carwash:moneycontrol', function()
    if Config.framework == "esx" then
        xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer.getMoney() >= Config.CarWashAmounth then
            xPlayer.removeMoney(Config.CarWashAmounth)
            TriggerClientEvent("magicarrow-carwash:moneyisaccepted", source)
        else
            TriggerClientEvent("QBCore:Notify", source, "You don't have enough money.", "error")
        end
    elseif Config.framework == "qb" then
        xPlayer = QBCore.Functions.GetPlayer(source)
        if xPlayer.Functions.RemoveMoney('cash', Config.CarWashAmounth) then
            TriggerClientEvent("magicarrow-carwash:moneyisaccepted", source)
        else
            TriggerClientEvent("QBCore:Notify", source, "You don't have enough money.", "error")
        end
    end
end)